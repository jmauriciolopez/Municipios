import { IsEnum, IsNotEmpty, IsOptional, IsString, IsUUID } from 'class-validator';

export enum TipoOrden {
  CORRECTIVA = 'correctiva',
  PREVENTIVA = 'preventiva',
  INSPECCION = 'inspeccion',
  EMERGENCIA = 'emergencia',
}

export class CreateOrdenDto {
  @IsUUID()
  municipioId: string;

  @IsOptional()
  @IsUUID()
  areaId?: string;

  @IsOptional()
  @IsUUID()
  incidenteId?: string;

  @IsOptional()
  @IsUUID()
  cuadrillaId?: string;

  @IsNotEmpty()
  @IsString()
  codigo: string;

  @IsNotEmpty()
  @IsString()
  titulo: string;

  @IsOptional()
  @IsString()
  descripcion?: string;

  @IsEnum(TipoOrden)
  tipo: TipoOrden;
}

import { Injectable } from '@nestjs/common';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { CreateOrdenDto } from './dto/create-orden.dto';
import { UpdateOrdenDto } from './dto/update-orden.dto';

@Injectable()
export class OrdenesService {
  findAll(query: PaginationDto) {
    return { items: [], page: query.page, limit: query.limit, total: 0 };
  }

  findOne(id: string) {
    return { id, titulo: 'Orden de trabajo de ejemplo' };
  }

  create(dto: CreateOrdenDto) {
    return { id: crypto.randomUUID(), ...dto };
  }

  update(id: string, dto: UpdateOrdenDto) {
    return { id, ...dto };
  }
}

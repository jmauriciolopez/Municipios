import { Injectable } from '@nestjs/common';

@Injectable()
export class DashboardService {
  getResumen(municipioId: string) {
    return {
      municipioId,
      incidentesAbiertos: 24,
      ordenesPendientes: 13,
      riesgosCriticos: 5,
      cuadrillasActivas: 7,
    };
  }
}

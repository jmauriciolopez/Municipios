import { Injectable } from '@nestjs/common';

@Injectable()
export class ActivosService {
  findAll() {
    return [];
  }

  findOne(id: string) {
    return { id, nombre: 'Activo ejemplo' };
  }
}

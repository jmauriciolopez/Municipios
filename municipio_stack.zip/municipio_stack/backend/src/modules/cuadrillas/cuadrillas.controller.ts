import { Controller, Get } from '@nestjs/common';
import { CuadrillasService } from './cuadrillas.service';

@Controller('cuadrillas')
export class CuadrillasController {
  constructor(private readonly cuadrillasService: CuadrillasService) {}

  @Get()
  findAll() {
    return this.cuadrillasService.findAll();
  }
}

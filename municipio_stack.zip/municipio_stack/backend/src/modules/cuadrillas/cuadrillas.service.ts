import { Injectable } from '@nestjs/common';

@Injectable()
export class CuadrillasService {
  findAll() {
    return [];
  }
}

import { Module } from '@nestjs/common';
import { CuadrillasController } from './cuadrillas.controller';
import { CuadrillasService } from './cuadrillas.service';

@Module({
  controllers: [CuadrillasController],
  providers: [CuadrillasService],
})
export class CuadrillasModule {}

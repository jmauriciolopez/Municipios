import { IsEnum, IsNotEmpty, IsOptional, IsString, IsUUID } from 'class-validator';

export enum PrioridadTicket {
  BAJA = 'baja',
  MEDIA = 'media',
  ALTA = 'alta',
  CRITICA = 'critica',
}

export enum OrigenTicket {
  CIUDADANO = 'ciudadano',
  INSPECTOR = 'inspector',
  INTERNO = 'interno',
  SENSOR = 'sensor',
  EVENTO_CLIMATICO = 'evento_climatico',
}

export class CreateIncidenteDto {
  @IsUUID()
  municipioId: string;

  @IsOptional()
  @IsUUID()
  areaId?: string;

  @IsOptional()
  @IsUUID()
  ubicacionId?: string;

  @IsNotEmpty()
  @IsString()
  titulo: string;

  @IsOptional()
  @IsString()
  descripcion?: string;

  @IsNotEmpty()
  @IsString()
  categoria: string;

  @IsEnum(PrioridadTicket)
  prioridad: PrioridadTicket;

  @IsEnum(OrigenTicket)
  origen: OrigenTicket;
}

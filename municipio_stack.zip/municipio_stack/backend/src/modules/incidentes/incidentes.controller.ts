import { Body, Controller, Get, Param, Patch, Post, Query } from '@nestjs/common';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { CreateIncidenteDto } from './dto/create-incidente.dto';
import { UpdateIncidenteDto } from './dto/update-incidente.dto';
import { IncidentesService } from './incidentes.service';

@Controller('incidentes')
export class IncidentesController {
  constructor(private readonly incidentesService: IncidentesService) {}

  @Get()
  findAll(@Query() query: PaginationDto) {
    return this.incidentesService.findAll(query);
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.incidentesService.findOne(id);
  }

  @Post()
  create(@Body() dto: CreateIncidenteDto) {
    return this.incidentesService.create(dto);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() dto: UpdateIncidenteDto) {
    return this.incidentesService.update(id, dto);
  }
}

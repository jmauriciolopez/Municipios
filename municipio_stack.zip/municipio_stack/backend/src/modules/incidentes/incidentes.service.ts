import { Injectable } from '@nestjs/common';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { CreateIncidenteDto } from './dto/create-incidente.dto';
import { UpdateIncidenteDto } from './dto/update-incidente.dto';

@Injectable()
export class IncidentesService {
  findAll(query: PaginationDto) {
    return { items: [], page: query.page, limit: query.limit, total: 0 };
  }

  findOne(id: string) {
    return { id, titulo: 'Incidente de ejemplo' };
  }

  create(dto: CreateIncidenteDto) {
    return { id: crypto.randomUUID(), ...dto };
  }

  update(id: string, dto: UpdateIncidenteDto) {
    return { id, ...dto };
  }
}

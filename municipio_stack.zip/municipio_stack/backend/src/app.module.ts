import { Module } from '@nestjs/common';
import { DashboardModule } from './modules/dashboard/dashboard.module';
import { IncidentesModule } from './modules/incidentes/incidentes.module';
import { OrdenesModule } from './modules/ordenes/ordenes.module';
import { ActivosModule } from './modules/activos/activos.module';
import { CuadrillasModule } from './modules/cuadrillas/cuadrillas.module';

@Module({
  imports: [DashboardModule, IncidentesModule, OrdenesModule, ActivosModule, CuadrillasModule],
})
export class AppModule {}

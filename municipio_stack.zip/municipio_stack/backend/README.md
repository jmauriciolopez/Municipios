# Backend NestJS - Starter

Estructura sugerida:

- `src/app.module.ts`
- `src/main.ts`
- `src/modules/dashboard`
- `src/modules/incidentes`
- `src/modules/ordenes`
- `src/modules/activos`
- `src/modules/cuadrillas`
- `src/common/dto/pagination.dto.ts`

Tecnologías previstas:
- NestJS
- class-validator
- class-transformer
- PostgreSQL
- Prisma o TypeORM

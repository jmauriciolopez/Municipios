# Municipio Stack

Incluye:

- `schema_postgres_inicial.sql`
- `backend/` con módulos y DTOs base de NestJS
- `frontend/` con rutas y componentes base de React

Uso sugerido:
1. Crear proyecto NestJS y copiar `backend/src`
2. Crear proyecto React/Vite y copiar `frontend/src`
3. Ejecutar el SQL en PostgreSQL
4. Conectar backend con Prisma o TypeORM
5. Consumir endpoints desde React

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TYPE estado_usuario AS ENUM ('activo', 'inactivo', 'suspendido');
CREATE TYPE rol_usuario AS ENUM ('super_admin', 'admin_municipio', 'coordinador_area', 'supervisor', 'operador', 'inspector', 'consulta');
CREATE TYPE estado_ticket AS ENUM ('detectado', 'asignado', 'en_proceso', 'resuelto', 'verificado', 'cancelado');
CREATE TYPE prioridad_ticket AS ENUM ('baja', 'media', 'alta', 'critica');
CREATE TYPE origen_ticket AS ENUM ('ciudadano', 'inspector', 'interno', 'sensor', 'evento_climatico');
CREATE TYPE tipo_activo AS ENUM ('luminaria', 'arbol', 'semáforo', 'camara', 'contenedor', 'vehiculo', 'edificio', 'otro');
CREATE TYPE tipo_orden AS ENUM ('correctiva', 'preventiva', 'inspeccion', 'emergencia');
CREATE TYPE estado_orden AS ENUM ('pendiente', 'planificada', 'en_ruta', 'en_ejecucion', 'resuelta', 'cerrada', 'cancelada');
CREATE TYPE tipo_evidencia AS ENUM ('foto', 'video', 'documento', 'audio');
CREATE TYPE estado_inspeccion AS ENUM ('programada', 'en_curso', 'finalizada', 'cancelada');

CREATE TABLE municipios (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre VARCHAR(150) NOT NULL,
  provincia VARCHAR(150),
  pais VARCHAR(80) DEFAULT 'Argentina',
  poblacion INTEGER,
  activo BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE areas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  municipio_id UUID NOT NULL REFERENCES municipios(id) ON DELETE CASCADE,
  nombre VARCHAR(120) NOT NULL,
  codigo VARCHAR(50),
  descripcion TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (municipio_id, nombre)
);

CREATE TABLE usuarios (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  municipio_id UUID NOT NULL REFERENCES municipios(id) ON DELETE CASCADE,
  area_id UUID REFERENCES areas(id) ON DELETE SET NULL,
  nombre VARCHAR(120) NOT NULL,
  apellido VARCHAR(120) NOT NULL,
  email VARCHAR(180) NOT NULL,
  telefono VARCHAR(40),
  password_hash TEXT NOT NULL,
  rol rol_usuario NOT NULL,
  estado estado_usuario NOT NULL DEFAULT 'activo',
  ultimo_acceso TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (municipio_id, email)
);

CREATE TABLE cuadrillas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  municipio_id UUID NOT NULL REFERENCES municipios(id) ON DELETE CASCADE,
  area_id UUID REFERENCES areas(id) ON DELETE SET NULL,
  nombre VARCHAR(120) NOT NULL,
  descripcion TEXT,
  activa BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE cuadrilla_miembros (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  cuadrilla_id UUID NOT NULL REFERENCES cuadrillas(id) ON DELETE CASCADE,
  usuario_id UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
  rol_en_cuadrilla VARCHAR(80),
  es_lider BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (cuadrilla_id, usuario_id)
);

CREATE TABLE ubicaciones (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  municipio_id UUID NOT NULL REFERENCES municipios(id) ON DELETE CASCADE,
  barrio VARCHAR(120),
  calle VARCHAR(150),
  altura VARCHAR(20),
  referencia TEXT,
  latitud NUMERIC(10,7),
  longitud NUMERIC(10,7),
  geohash VARCHAR(32),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE activos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  municipio_id UUID NOT NULL REFERENCES municipios(id) ON DELETE CASCADE,
  area_id UUID REFERENCES areas(id) ON DELETE SET NULL,
  ubicacion_id UUID REFERENCES ubicaciones(id) ON DELETE SET NULL,
  codigo_interno VARCHAR(80),
  nombre VARCHAR(150) NOT NULL,
  tipo tipo_activo NOT NULL,
  subtipo VARCHAR(100),
  marca VARCHAR(100),
  modelo VARCHAR(100),
  estado VARCHAR(80),
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (municipio_id, codigo_interno)
);

CREATE TABLE riesgos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  municipio_id UUID NOT NULL REFERENCES municipios(id) ON DELETE CASCADE,
  area_id UUID REFERENCES areas(id) ON DELETE SET NULL,
  ubicacion_id UUID REFERENCES ubicaciones(id) ON DELETE SET NULL,
  activo_id UUID REFERENCES activos(id) ON DELETE SET NULL,
  titulo VARCHAR(180) NOT NULL,
  descripcion TEXT,
  categoria VARCHAR(120) NOT NULL,
  subcategoria VARCHAR(120),
  probabilidad SMALLINT NOT NULL CHECK (probabilidad BETWEEN 1 AND 5),
  impacto SMALLINT NOT NULL CHECK (impacto BETWEEN 1 AND 5),
  nivel SMALLINT GENERATED ALWAYS AS (probabilidad * impacto) STORED,
  prioridad prioridad_ticket NOT NULL,
  origen origen_ticket NOT NULL,
  estado estado_ticket NOT NULL DEFAULT 'detectado',
  reportado_por_usuario_id UUID REFERENCES usuarios(id) ON DELETE SET NULL,
  fecha_deteccion TIMESTAMPTZ NOT NULL DEFAULT now(),
  fecha_vencimiento TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE incidentes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  municipio_id UUID NOT NULL REFERENCES municipios(id) ON DELETE CASCADE,
  area_id UUID REFERENCES areas(id) ON DELETE SET NULL,
  ubicacion_id UUID REFERENCES ubicaciones(id) ON DELETE SET NULL,
  riesgo_id UUID REFERENCES riesgos(id) ON DELETE SET NULL,
  activo_id UUID REFERENCES activos(id) ON DELETE SET NULL,
  titulo VARCHAR(180) NOT NULL,
  descripcion TEXT,
  categoria VARCHAR(120) NOT NULL,
  prioridad prioridad_ticket NOT NULL DEFAULT 'media',
  estado estado_ticket NOT NULL DEFAULT 'detectado',
  origen origen_ticket NOT NULL,
  asignado_a_usuario_id UUID REFERENCES usuarios(id) ON DELETE SET NULL,
  asignado_a_cuadrilla_id UUID REFERENCES cuadrillas(id) ON DELETE SET NULL,
  reportado_por_usuario_id UUID REFERENCES usuarios(id) ON DELETE SET NULL,
  fecha_ocurrencia TIMESTAMPTZ,
  fecha_asignacion TIMESTAMPTZ,
  fecha_resolucion TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE ordenes_trabajo (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  municipio_id UUID NOT NULL REFERENCES municipios(id) ON DELETE CASCADE,
  area_id UUID REFERENCES areas(id) ON DELETE SET NULL,
  incidente_id UUID REFERENCES incidentes(id) ON DELETE SET NULL,
  riesgo_id UUID REFERENCES riesgos(id) ON DELETE SET NULL,
  cuadrilla_id UUID REFERENCES cuadrillas(id) ON DELETE SET NULL,
  responsable_usuario_id UUID REFERENCES usuarios(id) ON DELETE SET NULL,
  codigo VARCHAR(50) NOT NULL,
  titulo VARCHAR(180) NOT NULL,
  descripcion TEXT,
  tipo tipo_orden NOT NULL DEFAULT 'correctiva',
  prioridad prioridad_ticket NOT NULL DEFAULT 'media',
  estado estado_orden NOT NULL DEFAULT 'pendiente',
  fecha_planificada TIMESTAMPTZ,
  fecha_inicio TIMESTAMPTZ,
  fecha_fin TIMESTAMPTZ,
  tiempo_estimado_minutos INTEGER,
  tiempo_real_minutos INTEGER,
  checklist JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (municipio_id, codigo)
);

CREATE TABLE evidencias (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  municipio_id UUID NOT NULL REFERENCES municipios(id) ON DELETE CASCADE,
  incidente_id UUID REFERENCES incidentes(id) ON DELETE CASCADE,
  riesgo_id UUID REFERENCES riesgos(id) ON DELETE CASCADE,
  orden_trabajo_id UUID REFERENCES ordenes_trabajo(id) ON DELETE CASCADE,
  tipo tipo_evidencia NOT NULL,
  archivo_url TEXT NOT NULL,
  miniatura_url TEXT,
  descripcion TEXT,
  capturada_por_usuario_id UUID REFERENCES usuarios(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE inspecciones (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  municipio_id UUID NOT NULL REFERENCES municipios(id) ON DELETE CASCADE,
  area_id UUID REFERENCES areas(id) ON DELETE SET NULL,
  inspector_id UUID REFERENCES usuarios(id) ON DELETE SET NULL,
  ubicacion_id UUID REFERENCES ubicaciones(id) ON DELETE SET NULL,
  activo_id UUID REFERENCES activos(id) ON DELETE SET NULL,
  titulo VARCHAR(180) NOT NULL,
  descripcion TEXT,
  estado estado_inspeccion NOT NULL DEFAULT 'programada',
  fecha_programada TIMESTAMPTZ,
  fecha_inicio TIMESTAMPTZ,
  fecha_fin TIMESTAMPTZ,
  formulario JSONB NOT NULL DEFAULT '{}'::jsonb,
  resultado JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE inventario_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  municipio_id UUID NOT NULL REFERENCES municipios(id) ON DELETE CASCADE,
  area_id UUID REFERENCES areas(id) ON DELETE SET NULL,
  nombre VARCHAR(150) NOT NULL,
  sku VARCHAR(80),
  unidad VARCHAR(30) NOT NULL DEFAULT 'unidad',
  stock_actual NUMERIC(12,2) NOT NULL DEFAULT 0,
  stock_minimo NUMERIC(12,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (municipio_id, sku)
);

CREATE TABLE ordenes_materiales (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  orden_trabajo_id UUID NOT NULL REFERENCES ordenes_trabajo(id) ON DELETE CASCADE,
  inventario_item_id UUID NOT NULL REFERENCES inventario_items(id) ON DELETE RESTRICT,
  cantidad NUMERIC(12,2) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (orden_trabajo_id, inventario_item_id)
);

CREATE TABLE auditoria_eventos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  municipio_id UUID REFERENCES municipios(id) ON DELETE CASCADE,
  usuario_id UUID REFERENCES usuarios(id) ON DELETE SET NULL,
  entidad VARCHAR(80) NOT NULL,
  entidad_id UUID,
  accion VARCHAR(80) NOT NULL,
  cambios JSONB,
  ip VARCHAR(64),
  user_agent TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_areas_municipio_id ON areas(municipio_id);
CREATE INDEX idx_usuarios_municipio_id ON usuarios(municipio_id);
CREATE INDEX idx_cuadrillas_municipio_id ON cuadrillas(municipio_id);
CREATE INDEX idx_ubicaciones_geo ON ubicaciones(latitud, longitud);
CREATE INDEX idx_activos_tipo ON activos(tipo);
CREATE INDEX idx_riesgos_estado_prioridad ON riesgos(estado, prioridad);
CREATE INDEX idx_incidentes_estado_prioridad ON incidentes(estado, prioridad);
CREATE INDEX idx_incidentes_asignado_cuadrilla ON incidentes(asignado_a_cuadrilla_id);
CREATE INDEX idx_ordenes_estado_prioridad ON ordenes_trabajo(estado, prioridad);
CREATE INDEX idx_ordenes_cuadrilla_id ON ordenes_trabajo(cuadrilla_id);
CREATE INDEX idx_inspecciones_estado ON inspecciones(estado);
CREATE INDEX idx_auditoria_entidad ON auditoria_eventos(entidad, entidad_id);

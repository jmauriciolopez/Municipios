type CardMetricProps = {
  titulo: string;
  valor: string | number;
  subtitulo?: string;
};

export function CardMetric({ titulo, valor, subtitulo }: CardMetricProps) {
  return (
    <div style={{ border: '1px solid #ddd', borderRadius: 12, padding: 16 }}>
      <div style={{ fontSize: 14, opacity: 0.8 }}>{titulo}</div>
      <div style={{ fontSize: 28, fontWeight: 700 }}>{valor}</div>
      {subtitulo ? <div style={{ fontSize: 12 }}>{subtitulo}</div> : null}
    </div>
  );
}

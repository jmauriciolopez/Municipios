import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { AppLayout } from '../layouts/AppLayout';
import { ActivosPage } from '../pages/ActivosPage';
import { CuadrillasPage } from '../pages/CuadrillasPage';
import { DashboardPage } from '../pages/DashboardPage';
import { IncidentesPage } from '../pages/IncidentesPage';
import { MapaPage } from '../pages/MapaPage';
import { OrdenesPage } from '../pages/OrdenesPage';

export function AppRouter() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<AppLayout />}>
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/incidentes" element={<IncidentesPage />} />
          <Route path="/ordenes" element={<OrdenesPage />} />
          <Route path="/mapa" element={<MapaPage />} />
          <Route path="/activos" element={<ActivosPage />} />
          <Route path="/cuadrillas" element={<CuadrillasPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

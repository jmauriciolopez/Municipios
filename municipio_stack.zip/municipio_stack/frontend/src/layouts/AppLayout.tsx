import { NavLink, Outlet } from 'react-router-dom';

const links = [
  { to: '/dashboard', label: 'Dashboard' },
  { to: '/incidentes', label: 'Incidentes' },
  { to: '/ordenes', label: 'Órdenes' },
  { to: '/mapa', label: 'Mapa' },
  { to: '/activos', label: 'Activos' },
  { to: '/cuadrillas', label: 'Cuadrillas' },
];

export function AppLayout() {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '260px 1fr', minHeight: '100vh' }}>
      <aside style={{ borderRight: '1px solid #ddd', padding: 16 }}>
        <h2>Municipio SyH</h2>
        <nav style={{ display: 'grid', gap: 8 }}>
          {links.map((link) => (
            <NavLink key={link.to} to={link.to}>
              {link.label}
            </NavLink>
          ))}
        </nav>
      </aside>
      <main style={{ padding: 24 }}>
        <Outlet />
      </main>
    </div>
  );
}

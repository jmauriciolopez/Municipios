import { CardMetric } from '../components/CardMetric';

export function DashboardPage() {
  return (
    <div>
      <h1>Dashboard</h1>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
        <CardMetric titulo="Incidentes abiertos" valor={24} />
        <CardMetric titulo="Órdenes pendientes" valor={13} />
        <CardMetric titulo="Riesgos críticos" valor={5} />
        <CardMetric titulo="Cuadrillas activas" valor={7} />
      </div>
    </div>
  );
}

import { DataTable } from '../components/DataTable';

const data = [
  { nombre: 'Cuadrilla Norte', area: 'Luminaria', activa: 'Sí' },
  { nombre: 'Poda Centro', area: 'Poda', activa: 'Sí' },
];

export function CuadrillasPage() {
  return (
    <div>
      <h1>Cuadrillas</h1>
      <DataTable
        data={data}
        columns={[
          { key: 'nombre', header: 'Nombre' },
          { key: 'area', header: 'Área' },
          { key: 'activa', header: 'Activa' },
        ]}
      />
    </div>
  );
}

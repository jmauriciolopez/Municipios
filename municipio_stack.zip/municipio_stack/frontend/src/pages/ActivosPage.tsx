import { DataTable } from '../components/DataTable';

const data = [
  { nombre: 'Poste 1032', tipo: 'luminaria', estado: 'fuera_de_servicio' },
  { nombre: 'Jacarandá Plaza Sur', tipo: 'arbol', estado: 'requiere_poda' },
];

export function ActivosPage() {
  return (
    <div>
      <h1>Activos</h1>
      <DataTable
        data={data}
        columns={[
          { key: 'nombre', header: 'Nombre' },
          { key: 'tipo', header: 'Tipo' },
          { key: 'estado', header: 'Estado' },
        ]}
      />
    </div>
  );
}

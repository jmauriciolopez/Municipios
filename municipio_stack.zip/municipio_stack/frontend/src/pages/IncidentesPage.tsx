import { DataTable } from '../components/DataTable';

const data = [
  { titulo: 'Luminaria apagada', categoria: 'Luminaria', prioridad: 'alta', estado: 'asignado' },
  { titulo: 'Árbol con ramas peligrosas', categoria: 'Poda', prioridad: 'critica', estado: 'en_proceso' },
];

export function IncidentesPage() {
  return (
    <div>
      <h1>Incidentes</h1>
      <DataTable
        data={data}
        columns={[
          { key: 'titulo', header: 'Título' },
          { key: 'categoria', header: 'Categoría' },
          { key: 'prioridad', header: 'Prioridad' },
          { key: 'estado', header: 'Estado' },
        ]}
      />
    </div>
  );
}

export function MapaPage() {
  return (
    <div>
      <h1>Mapa operativo</h1>
      <div style={{ height: 480, border: '1px dashed #bbb', borderRadius: 12, display: 'grid', placeItems: 'center' }}>
        Acá va el mapa con Leaflet o Mapbox
      </div>
    </div>
  );
}

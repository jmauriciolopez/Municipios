import { DataTable } from '../components/DataTable';

const data = [
  { codigo: 'OT-0001', titulo: 'Reemplazo de luminaria', cuadrilla: 'Cuadrilla Norte', estado: 'pendiente' },
  { codigo: 'OT-0002', titulo: 'Poda preventiva', cuadrilla: 'Poda Centro', estado: 'en_ejecucion' },
];

export function OrdenesPage() {
  return (
    <div>
      <h1>Órdenes de trabajo</h1>
      <DataTable
        data={data}
        columns={[
          { key: 'codigo', header: 'Código' },
          { key: 'titulo', header: 'Título' },
          { key: 'cuadrilla', header: 'Cuadrilla' },
          { key: 'estado', header: 'Estado' },
        ]}
      />
    </div>
  );
}

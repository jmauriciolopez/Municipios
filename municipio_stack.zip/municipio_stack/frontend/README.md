# Frontend React - Starter

Estructura sugerida:

- `src/router/AppRouter.tsx`
- `src/layouts/AppLayout.tsx`
- `src/pages/DashboardPage.tsx`
- `src/pages/IncidentesPage.tsx`
- `src/pages/OrdenesPage.tsx`
- `src/pages/MapaPage.tsx`
- `src/pages/ActivosPage.tsx`
- `src/pages/CuadrillasPage.tsx`
- `src/components/CardMetric.tsx`
- `src/components/DataTable.tsx`

Sugerencia:
- React + React Router
- TanStack Query
- Axios
- Tailwind o MUI
- Leaflet o Mapbox para mapa
